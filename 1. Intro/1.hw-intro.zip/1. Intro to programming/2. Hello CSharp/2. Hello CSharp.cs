﻿using System;

class Hello_CSharp
{
    static void Main()
    {
        Console.WriteLine("Hello C#!");
    }
}

