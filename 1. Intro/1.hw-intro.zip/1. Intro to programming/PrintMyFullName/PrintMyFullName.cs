﻿using System;

    class PrintMyFullName
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Valentin Kolev");
        }
    }
