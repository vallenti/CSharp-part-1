﻿using System;

    class PrintSquareRoot
    {
        static void Main()
        {
            Console.WriteLine(Math.Sqrt(12345));
        }
    }

