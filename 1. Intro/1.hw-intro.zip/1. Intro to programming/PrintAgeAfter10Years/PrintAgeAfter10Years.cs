﻿using System;

class PrintAgeAfter10Years
{
    static void Main()
    {
        Console.WriteLine("Input your age: ");
        int age = int.Parse(Console.ReadLine());
        Console.WriteLine(age+10);

    }
}

