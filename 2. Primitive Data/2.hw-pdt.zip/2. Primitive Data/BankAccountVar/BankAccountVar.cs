﻿using System;

class BankAccountVar
{
    static void Main()
    {
        string firstName;
        string midName;
        string lastName;
        string fullName(firstName+" "+midName+" "+lastName);
        decimal money;
        string bankName;
        string iban;
        string bic;
        long cCard1;
        long cCard2;
        long cCard3;
    }
}
