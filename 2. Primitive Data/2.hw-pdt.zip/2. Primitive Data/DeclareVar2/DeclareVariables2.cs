﻿using System;

class DeclareVar2
{
    static void Main()
    {
        float a = 12.345f;
        float b = 3456.091f;
        double c = 34.567839023d;
        double d = 8923.1234857d;
    }
}

