﻿using System;

class VarIsFemale
{
    static void Main()
    {
        bool isFemale = false;
    }
}

