﻿using System;

class DeclareCharVar
{
    static void Main()
    {
        char a = '\u0048';
    }
}
