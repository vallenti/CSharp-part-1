﻿using System;

class DeclareFirmVar
{
    static void Main()
    {
        string firstName;
        string lastName;
        byte age;
        char sex;
        ushort idNumber;
        uint uniqueNumber;
    }
}

