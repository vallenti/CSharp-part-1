﻿using System;

class NumberInHexFormat
{
    static void Main()
    {
        int a = 0xFE;
    }
}

