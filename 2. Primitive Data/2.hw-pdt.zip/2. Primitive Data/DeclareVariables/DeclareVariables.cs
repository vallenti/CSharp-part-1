﻿using System;

class DeclareVariables
{
    static void Main()
    {
        ushort a = 52130;
        sbyte b= -115;
        uint c = 4825932;
        short d = 97;
        short e = -10000;
    }
}

